const SUPABASE_URL = "https://bzcvckrlettgnauvcmaz.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ6Y3Zja3JsZXR0Z25hdXZjbWF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYzODg4ODEsImV4cCI6MjEwMTk2NDg4MX0.QzUohc8ykAehZgRHTqFkM38HIBQemtd9godKDpVikCc";

const BASE = `${SUPABASE_URL}/rest/v1`;

async function pgFetch(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const j = await res.json();
      msg = j.message || j.error_description || msg;
    } catch (_) {}
    throw new Error(`Supabase ${res.status}: ${msg}`);
  }
  if (res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

export const pg = {
  select: (table, query = "") => pgFetch(`/${table}?select=*${query}`),
  upsert: (table, rows) =>
    pgFetch(`/${table}`, {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(rows),
    }),
  update: (table, id, patch) =>
    pgFetch(`/${table}?id=eq.${id}`, {
      method: "PATCH",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify(patch),
    }),
  deleteIn: (table, ids) =>
    pgFetch(`/${table}?id=in.(${ids.join(",")})`, {
      method: "DELETE",
      headers: { Prefer: "return=minimal" },
    }),
};
