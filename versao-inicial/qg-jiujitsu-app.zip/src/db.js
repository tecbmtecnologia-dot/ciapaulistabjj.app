import { pg } from "./supabaseClient.js";

/* Mapas de campo: chave usada na interface -> coluna no banco. */
const MAPS = {
  academia: {
    nome: "nome", chavePix: "chave_pix", logo: "logo", termoPadrao: "termo_padrao",
    termoPdf: "termo_pdf", termoPdfNome: "termo_pdf_nome", senhaAdmin: "senha_admin",
  },
  faixas: {
    id: "id", nome: "nome", cor: "cor", texto: "texto", borda: "borda",
    grausMax: "graus_max", tempoMinimoAnos: "tempo_minimo_anos", aulasPorGrau: "aulas_por_grau",
    categoria: "categoria", observacoes: "observacoes", ordem: "ordem",
  },
  planos: { id: "id", nome: "nome", valor: "valor", periodicidade: "periodicidade" },
  turmas: { id: "id", nome: "nome", dias: "dias", horario: "horario" },
  professores: {
    id: "id", nome: "nome", email: "email", especialidade: "especialidade",
    telefone: "telefone", endereco: "endereco", faixaId: "faixa_id", grau: "grau",
  },
  alunos: {
    id: "id", nome: "nome", email: "email", senha: "senha", primeiroAcesso: "primeiro_acesso",
    telefone: "telefone", endereco: "endereco", contatoEmergenciaNome: "contato_emergencia_nome",
    contatoEmergenciaTelefone: "contato_emergencia_telefone", foto: "foto", faixaId: "faixa_id",
    grau: "grau", dataNascimento: "data_nascimento", matricula: "matricula", planoId: "plano_id",
    diaVencimento: "dia_vencimento", ultimoPagamento: "ultimo_pagamento",
    checkinsDesdeGraduacao: "checkins_desde_graduacao", termoAceito: "termo_aceito",
    termoAceitoEm: "termo_aceito_em", termoAssinadoManual: "termo_assinado_manual",
  },
  pagamentos: { id: "id", alunoId: "aluno_id", data: "data", valor: "valor" },
  sessoes_checkin: {
    id: "id", treinoId: "turma_id", professorId: "professor_id", codigo: "codigo",
    criadoEm: "criado_em", ativa: "ativa",
  },
  checkins: { id: "id", sessaoId: "sessao_id", alunoId: "aluno_id", dataHora: "data_hora" },
};

function toDb(entity, obj) {
  const map = MAPS[entity];
  const row = {};
  for (const [jsKey, dbKey] of Object.entries(map)) {
    if (obj[jsKey] === undefined) continue;
    row[dbKey] = obj[jsKey] === "" && ["email", "faixaId", "planoId"].includes(jsKey) ? null : obj[jsKey];
  }
  return row;
}

function fromDb(entity, row) {
  const map = MAPS[entity];
  const obj = {};
  for (const [jsKey, dbKey] of Object.entries(map)) obj[jsKey] = row[dbKey];
  return obj;
}

/* Upsert de todas as linhas atuais + remoção das que não existem mais na lista (cobre criar, editar e excluir). */
async function syncTable(entity, items) {
  const rows = items.map((it) => toDb(entity, it));
  const existing = await pg.select(entity, "&select=id");
  const existingIds = (existing || []).map((r) => r.id);
  const nextIds = items.map((it) => it.id);
  const toDelete = existingIds.filter((id) => !nextIds.includes(id));

  if (rows.length) await pg.upsert(entity, rows);
  if (toDelete.length) await pg.deleteIn(entity, toDelete);
}

export async function loadAll() {
  const [academiaRows, faixasRows, planosRows, turmasRows, professoresRows, alunosRows, pagamentosRows, sessoesRows, checkinsRows] = await Promise.all([
    pg.select("academia", "&limit=1"),
    pg.select("faixas", "&order=ordem.asc"),
    pg.select("planos"),
    pg.select("turmas"),
    pg.select("professores"),
    pg.select("alunos"),
    pg.select("pagamentos"),
    pg.select("sessoes_checkin"),
    pg.select("checkins"),
  ]);

  if (!academiaRows || academiaRows.length === 0) {
    throw new Error("Tabela 'academia' está vazia — rode o script SQL no Supabase antes de conectar o app.");
  }

  const academia = fromDb("academia", academiaRows[0]);
  academia.id = academiaRows[0].id;

  const pagamentosPorAluno = {};
  (pagamentosRows || []).forEach((row) => {
    const p = fromDb("pagamentos", row);
    if (!pagamentosPorAluno[p.alunoId]) pagamentosPorAluno[p.alunoId] = [];
    pagamentosPorAluno[p.alunoId].push({ id: p.id, data: p.data, valor: Number(p.valor) });
  });

  const alunos = (alunosRows || []).map((row) => {
    const a = fromDb("alunos", row);
    a.grau = Number(a.grau) || 0;
    a.diaVencimento = a.diaVencimento === null ? null : Number(a.diaVencimento);
    a.checkinsDesdeGraduacao = Number(a.checkinsDesdeGraduacao) || 0;
    a.pagamentos = pagamentosPorAluno[a.id] || [];
    return a;
  });

  const faixas = (faixasRows || []).map((row) => {
    const f = fromDb("faixas", row);
    f.grausMax = Number(f.grausMax) || 0;
    f.tempoMinimoAnos = f.tempoMinimoAnos === null ? null : Number(f.tempoMinimoAnos);
    f.aulasPorGrau = f.aulasPorGrau === null ? null : Number(f.aulasPorGrau);
    return f;
  });

  const planos = (planosRows || []).map((row) => { const p = fromDb("planos", row); p.valor = Number(p.valor); return p; });
  const turmas = (turmasRows || []).map((row) => fromDb("turmas", row));
  const professores = (professoresRows || []).map((row) => { const p = fromDb("professores", row); p.grau = Number(p.grau) || 0; return p; });
  const sessoes = (sessoesRows || []).map((row) => fromDb("sessoes_checkin", row));
  const checkins = (checkinsRows || []).map((row) => fromDb("checkins", row));

  return { academia, faixas, planos, turmas, professores, alunos, sessoes, checkins };
}

export async function saveAll(next) {
  const academiaRow = toDb("academia", next.academia);
  await pg.update("academia", next.academia.id, academiaRow);

  const faixasComOrdem = next.faixas.map((f, i) => ({ ...f, ordem: i }));

  await syncTable("faixas", faixasComOrdem);
  await syncTable("planos", next.planos);
  await syncTable("turmas", next.turmas);
  await syncTable("professores", next.professores);
  await syncTable("alunos", next.alunos);
  await syncTable("sessoes_checkin", next.sessoes);
  await syncTable("checkins", next.checkins);

  const todosPagamentos = next.alunos.flatMap((a) => (a.pagamentos || []).map((p) => ({ ...p, alunoId: a.id })));
  await syncTable("pagamentos", todosPagamentos);
}
